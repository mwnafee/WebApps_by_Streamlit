import subprocess as sp
import os
# This function will call the python subprocess module's Popen method to invoke a system executable program.
def subprocess_popen_exmple():
    
    # Create the windows executable file command line arguments array.
    cmd_param_arrray = []
    
    # Add the command line arguments 
    cmd_param_arrray.append('start ')
    cmd_param_arrray.append('/wait ')
    
    # Get the windows system directory
    win_dir_path = os.environ['WINDIR'] + "\\System32\\"
    
    # Get the windows executable file ( notepad.exe ) path.
    cmd_executeable_file_path = os.path.join(win_dir_path, 'notepad.exe')
    # Add the above windows  executable file path to the command line arguments list.
    cmd_param_arrray.append(cmd_executeable_file_path)
    
    # Print out the command line arguments list elements.
    print(cmd_param_arrray)
    
    # Invoke the windows program with the python subprocess module's Popen() method.
    child = sp.Popen(cmd_param_arrray)
if __name__ == '__main__':
    
    subprocess_popen_exmple()