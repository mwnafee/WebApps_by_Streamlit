from enum import unique
import streamlit as st
import pandas as pd
import base64
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

st.title('NFL Football Stats(Rushing) Explorer')
st.markdown("""
This app performs simple webscraping of NBA Player Stats Data!
* **Python libraries:** base64, pandas, streamlit
* **Data source: **[Basketball-reference.com](https://www.pro-football-reference.com)
""")
st.sidebar.header('User Input Features')
selected_year= st.sidebar.selectbox("Year",list(reversed(range(1950,2020))))

#web scraping of NBA player stats
@st.cache
def load_data(year):
    url="https://www.pro-football-reference.com/years/"+str(selected_year)+"/rushing.htm"
    html=pd.read_html(url, header=0)
    df= html[0]
    raw= df.drop(df[df.Age=='Age'].index)
    raw=raw.fillna(0)
    playerstats= raw.drop(['Rk'],axis=1)
    return playerstats
playerstats=load_data(selected_year)
#Sidebar - Team Selection
sorted_unique_team=sorted(playerstats.Tm.unique())
selected_team =st.sidebar.multiselect('Team',sorted_unique_team,sorted_unique_team)

#Sidebar - Position Selection
unique_pos= ['C','PF','SF','PG','SG']
selected_pos= st.sidebar.multiselect('Position',unique_pos,unique_pos)

df_selected_team = playerstats[(playerstats.Tm.isin(selected_team)) & (playerstats.Pos.isin(selected_pos))]

st.header('Display Player Stats of Selected Team(s)')
st.write('Data Dimension: ' + str(df_selected_team.shape[0]) + ' rows and ' + str(df_selected_team.shape[1]) + ' columns.')
test = df_selected_team.astype(str) #work_around
st.dataframe(test)

print("Football")